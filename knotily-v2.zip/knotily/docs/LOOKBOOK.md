# “On the body” photos

The home page strip “On the body” shows the **photos** you upload to products (Dashboard → Products → Previews). Each photo links to its product and colour, and opens full screen with “Shop this look”. Until you have uploaded any, the strip shows the 3D garments with “Model preview coming soon”.

Product pages show all of that product's photos and videos in **Previews**.

## Trying photos before you upload them

Open the site with `?preview=edit` at the end of the address (e.g. `https://test.knotily.in/?preview=edit`). Every slot in the strip becomes a drop zone: drag a photo onto it to see how it looks in place. These trial photos stay in your browser only — shoppers never see them. Leave with `?preview=off`.

When you're happy, upload the real files to the product in the dashboard and press Save.

Photo tips: portrait 4:5 (e.g. 1600 × 2000 px), JPG or WebP under ~500 KB, consistent lighting across a drop.
