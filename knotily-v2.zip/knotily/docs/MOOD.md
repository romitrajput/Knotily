# Mood rooms

The site theme is always Knot’ily royal blue and orange. The garment stages re-light themselves around the tee in focus: the rack hero, the product viewer, the product tiles and the garment's edge light. As the rack turns, or a colour tag is picked, they crossfade (0.9 s) to that colourway's "room". With no tee featured, the room is brand blue.

Code: `src/lib/mood.js` (palettes and rules), `src/styles/tokens.css` (registered `--room`, `--spot`, `--glow` so they animate).

## The four rules

1. **Same-hue room.** The background is a very deep shade of the garment's own hue. The scene reads as one colour story, and the tee looks like the light source. A hue looks richer surrounded by darker members of its own family than next to an unrelated colour.
2. **Figure–ground contrast.** Light garments (White Lace, Lip Gloss, Cold Shoulder Blue) get the darkest rooms. Dark garments (Latex Black, Bruise) get a lifted, smoky spotlight so the silhouette still separates from the background. The eye has to find the product instantly.
3. **Association.** Each room leans into what people commonly read in that colour:

| Colourway | Room | Reads as |
|---|---|---|
| Red Light | deep crimson, strong red glow | heat, urgency, arousal: the classic "act now" colour |
| Hot Pink | magenta-plum | flirty, playful, confident |
| Lip Gloss | berry | soft, teasing |
| Latex Black | smoky violet-grey | power, mystery, luxury |
| Bruise | indigo night | luxury, secrecy |
| Hangover | dark wine | moody, slow |
| White Lace | warm dark taupe | "innocent", made cheeky by the red print |
| Poison | dark emerald | toxic, rebellious, attention-grabbing |
| Cold Shoulder Blue | midnight navy | cool, distant, calm |

4. **Readability first.** Every room stays dark enough for the warm-white text to keep WCAG AA contrast. The orange Buy now button stays orange in every room, so it is always the most saturated, most clickable thing on screen.

Any colour not in the table gets a room computed with the same rules (hue kept, saturation capped, lightness ~5% for the background and ~20% for the spotlight, brighter when the garment is dark).

## Caveat

Colour associations are cultural and statistical, not guaranteed. Treat this as a strong default and A/B-test it: for example, Buy now rate with mood backgrounds on versus a fixed background.
