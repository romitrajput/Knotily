# Suggestions — not built, waiting for your go-ahead

None of these are in the code. Tell me which ones you want (I can show a demo first).

| # | Suggestion | Why | Effort |
|---|---|---|---|
| 1 | **Cash on delivery** (optional, with a fee and an OTP check on the phone number) | Many Indian shoppers, especially first-timers, only buy with COD. Cost: more returns-to-origin. | Medium |
| 2 | **Refund from the dashboard** — Cancel/Refund triggers the Razorpay refund automatically | Today you mark it refunded, then refund in Razorpay separately. | Small |
| 3 | **GST invoice PDF** attached to the receipt email (your GSTIN, HSN code, tax split) | Required once you're GST-registered; customers ask for it. | Medium |
| 4 | **Courier integration** (Shiprocket or Delhivery): create the shipment from the order, tracking link in the “shipped” email | Saves copy-pasting addresses; shoppers can track. | Medium |
| 5 | **PIN code auto-fill** of city/state and a delivery-time estimate | Fewer address mistakes, faster checkout on phones. | Small |
| 6 | **Drop alerts sign-up** (the old footer newsletter form was removed because it didn't save anything) | Build a list for Drop 05 launches, with consent. | Small |
| 7 | **Shopper-written reviews** from verified buyers, with your approval before they show | Social proof without typing reviews yourself. | Medium |
| 8 | **Abandoned-bag email** (only to shoppers who agreed) | Typically recovers a share of unfinished checkouts. | Small |
| 9 | **Self-hosted fonts** instead of Google Fonts | Faster first load in India, no third-party request (privacy). | Small |
| 10 | **Error monitoring + uptime alerts** (e.g. Sentry free tier, Better Stack) | You hear about problems before customers do. | Small |
| 11 | **Automatic photo optimisation** on upload (resize + WebP) | Faster pages on mobile data. | Small |
| 12 | **One-click account deletion** in the dashboard (instead of Supabase → Users) | Simpler DPDP requests. | Small |
| 13 | **Size exchange** request from the order page | Most apparel returns are size swaps. | Medium |
| 14 | **Search** in the shop | Useful once the range grows past ~30 pieces. | Small |
