import { config } from '../config.js';
import { showConsentBanner } from './consentBanner.js';
import { logoSVG } from '../brand/logo.js';
import { esc } from '../lib/util.js';

export function mountFooter(el) {
  const year = new Date().getFullYear();
  el.innerHTML = `
    <footer class="footer">
      <div class="footer-cols">
        <nav aria-label="Shop links">
          <h3>Shop</h3>
          <ul data-footer-cats>
            <li><a href="/shop">All pieces</a></li>
          </ul>
        </nav>
        <nav aria-label="Help links">
          <h3>Help</h3>
          <ul>
            <li><a href="/story#sizing">Size guide</a></li>
            <li><a href="/story#shipping">Shipping and returns</a></li>
            <li><a href="/account">Your account</a></li>
            <li><a href="mailto:${config.supportEmail}" data-external>${config.supportEmail}</a></li>
          </ul>
        </nav>
        <nav aria-label="Social links">
          <h3>Follow</h3>
          <ul>
            <li><a href="${config.instagram}" target="_blank" rel="noopener">Instagram</a></li>
            <li><a href="https://www.pinterest.com/" target="_blank" rel="noopener">Pinterest</a></li>
          </ul>
        </nav>
      </div>
      <div class="footer-base">
        <div class="footer-word" aria-hidden="true">${logoSVG({ cls: 'wordmark' })}<span class="footer-made">MADE</span></div>
        <p class="footer-legal">© ${year} Knot’ily. Prices in INR, taxes included. <a href="/privacy">Privacy</a> · <a href="/terms">Terms</a> · <button type="button" class="link-btn" data-cookie-settings>Cookie settings</button></p>
      </div>
    </footer>`;

  el.querySelector('[data-cookie-settings]').addEventListener('click', () => showConsentBanner({ force: true }));
}

export function renderFooterCategories(cats) {
  const ul = document.querySelector('[data-footer-cats]');
  if (!ul) return;
  ul.innerHTML = `<li><a href="/shop">All pieces</a></li>` + cats.map((c) => `<li><a href="/shop/${encodeURIComponent(c.id)}">${esc(c.label)}</a></li>`).join('');
}
