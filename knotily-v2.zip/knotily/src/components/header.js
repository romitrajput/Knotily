import { subscribe, snapshot } from '../store/cart.js';
import { openCart } from './cartDrawer.js';
import { $, $$ } from '../lib/util.js';
import { logoSVG } from '../brand/logo.js';
import { onSession, currentUser } from '../store/session.js';

export function mountHeader(el) {
  el.innerHTML = `
    <header class="hdr" data-header>
      <nav class="hdr-nav" aria-label="Main">
        <a href="/shop">Shop</a>
        <a href="/shop/tees" class="hide-sm">Oversized tees</a>
        <a href="/story" class="hide-sm">Story</a>
      </nav>
      <a class="logo" href="/" aria-label="Knot’ily home">${logoSVG({ label: 'Knot’ily' })}</a>
      <div class="hdr-actions">
        <a class="hdr-link" href="/admin" data-owner-link hidden>Owner</a>
        <a class="hdr-link" href="/account" data-account-link>Log in</a>
        <button class="bag-btn" type="button" data-open-cart aria-label="Open bag, 0 items">Bag <span data-bag-count>(0)</span></button>
      </div>
    </header>`;

  $('[data-open-cart]', el).addEventListener('click', openCart);
  const count = $('[data-bag-count]', el);
  const btn = $('[data-open-cart]', el);
  const update = (s) => {
    const prev = Number(count.dataset.n || 0);
    count.textContent = `(${s.count})`;
    count.dataset.n = s.count;
    btn.setAttribute('aria-label', `Open bag, ${s.count} item${s.count === 1 ? '' : 's'}`);
    if (s.count > prev) {
      btn.classList.remove('bump');
      void btn.offsetWidth;
      btn.classList.add('bump');
    }
  };
  update(snapshot());
  subscribe(update);

  const acc = $('[data-account-link]', el);
  const own = $('[data-owner-link]', el);
  const who = (u) => {
    acc.textContent = u ? 'Account' : 'Log in';
    acc.setAttribute('aria-label', u ? `Your account (${u.email})` : 'Log in or create an account');
    own.hidden = u?.role !== 'owner';
  };
  who(currentUser());
  onSession(who);

  const header = $('[data-header]', el);
  const onScroll = () => header.classList.toggle('is-scrolled', window.scrollY > 4);
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
}

export function setActiveNav(path) {
  $$('.hdr-nav a').forEach((a) => {
    const href = a.getAttribute('href');
    const active = href === '/shop' ? path === '/shop' || (path.startsWith('/shop/') && !path.startsWith('/shop/tees')) : path === href || path.startsWith(href + '/');
    if (active) a.setAttribute('aria-current', 'page');
    else a.removeAttribute('aria-current');
  });
}
