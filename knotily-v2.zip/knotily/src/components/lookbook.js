// "On the body" model preview section + lightbox + preview mode.
//
// Public mode: shows the photos the owner uploaded to each product (owner dashboard →
// Products → Previews). Until there are any, slots show the 3D garment and
// "Model preview coming soon".
// Preview mode (?preview=edit): every slot becomes a drop zone. Trial photos are
// saved in this browser (IndexedDB) so you can judge them in place before publishing.
import { getProductById, allProducts } from '../services/catalog.js';
import { garmentImg, hydrate } from './media.js';
import { idbGet, idbSet, idbDel } from '../lib/idb.js';
import { esc, storage, uid, $, $$ } from '../lib/util.js';

const MODE_KEY = 'knotily.previewMode';
const extras = storage('knotily.preview.extraLooks', []);

export function isPreviewMode() {
  const q = new URLSearchParams(location.search).get('preview');
  try {
    if (q === 'edit') sessionStorage.setItem(MODE_KEY, '1');
    if (q === 'off') sessionStorage.removeItem(MODE_KEY);
    return sessionStorage.getItem(MODE_KEY) === '1';
  } catch {
    return q === 'edit';
  }
}

function published() {
  const looks = [];
  for (const p of allProducts()) {
    for (const m of p.media || []) {
      if (m.kind === 'image') looks.push({ id: m.id, productId: p.id, color: m.color || p.colors[0]?.name, image: m.url, model: '', caption: m.alt || '' });
    }
  }
  if (looks.length) return looks.slice(0, 16);
  // nothing uploaded yet: one placeholder slot per product (3D garment)
  return allProducts().slice(0, 10).map((p) => ({ id: `ph-${p.id}`, productId: p.id, color: p.colors[0]?.name, image: '', model: '', caption: '' }));
}

function allLooks(edit) {
  return edit ? [...published(), ...extras.read()] : published();
}

function slotHTML(look, edit) {
  const p = getProductById(look.productId);
  if (!p) return '';
  const c = p.colors.find((x) => x.name === look.color) || p.colors[0];
  const label = `${p.name} in ${c.name}${look.model ? `, worn by ${look.model}` : ''}`;
  return `
    <figure class="look" data-look="${esc(look.id)}" ${look.image ? 'data-has-image' : ''}>
      <div class="look-frame">
        ${
          look.image
            ? `<img class="look-img" src="${esc(look.image)}" alt="${esc(label)}" loading="lazy" decoding="async" />`
            : `<img class="look-img" alt="${esc(label)}" hidden />
               <div class="look-placeholder">${garmentImg(p, c)}<span>Model preview coming soon</span></div>`
        }
        <button type="button" class="look-open" data-open aria-label="View ${esc(label)} larger" ${look.image ? '' : 'hidden'}></button>
        ${
          edit
            ? `<label class="look-drop">
                 <input type="file" accept="image/*" data-file />
                 <span class="look-drop-text"><span class="when-empty">Drop a model photo<br />or click to choose</span><span class="when-filled">Replace photo</span></span>
               </label>
               <div class="look-tools">
                 <button type="button" class="chip-btn" data-remove hidden>Remove trial photo</button>
               </div>`
            : ''
        }
      </div>
      <figcaption>
        <a href="/product/${p.slug}?color=${encodeURIComponent(c.name)}">${esc(p.name)}</a>
        <span>${esc(c.name)}${look.model ? `, ${esc(look.model)}` : ''}</span>
      </figcaption>
    </figure>`;
}

export function lookbookHTML({ productId = null, title = 'On the body', intro = '' } = {}) {
  const edit = isPreviewMode();
  const looks = allLooks(edit).filter((l) => !productId || l.productId === productId);
  if (!looks.length && !edit) return '';
  const addTile = edit
    ? `<div class="look look-add">
         <form class="look-add-form" data-add>
           <p>Add another look</p>
           <label class="sr-only" for="add-product">Piece</label>
           <select id="add-product" name="product">${allProducts().filter((p) => !productId || p.id === productId).map((p) => `<option value="${p.id}">${esc(p.name)}</option>`).join('')}</select>
           <button class="btn btn-line" type="submit">Add slot</button>
         </form>
       </div>`
    : '';
  return `
  <section class="section looks" aria-labelledby="looks-title" data-looks ${productId ? `data-product="${productId}"` : ''} ${edit ? 'data-edit' : ''}>
    <div class="section-head">
      <h2 id="looks-title" class="display-sm">${esc(title)}</h2>
      ${intro ? `<p>${intro}</p>` : ''}
      <div class="looks-nav">
        <button type="button" class="round-btn" data-scroll="-1" aria-label="Previous looks"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="1.8"/></svg></button>
        <button type="button" class="round-btn" data-scroll="1" aria-label="More looks"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 5l7 7-7 7" fill="none" stroke="currentColor" stroke-width="1.8"/></svg></button>
      </div>
    </div>
    ${
      edit
        ? `<div class="preview-banner" role="note">
             <p><strong>Preview mode.</strong> Drop model photos onto any slot to see how they look on the site. They are saved in this browser only, so customers won't see them. To publish, upload them to the product in the owner dashboard (Products → Previews).</p>
             <a class="btn btn-line" href="?preview=off">Exit preview mode</a>
           </div>`
        : ''
    }
    <div class="look-strip" data-strip>
      ${looks.map((l) => slotHTML(l, edit)).join('')}
      ${addTile}
    </div>
    <dialog class="lightbox" data-lightbox aria-label="Model preview">
      <div class="lb-inner">
        <img class="lb-img" alt="" data-lb-img />
        <div class="lb-bar">
          <p class="lb-cap" data-lb-cap></p>
          <a class="btn" data-lb-shop href="#">Shop this look</a>
        </div>
        <button type="button" class="round-btn lb-prev" data-lb="-1" aria-label="Previous photo"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="1.8"/></svg></button>
        <button type="button" class="round-btn lb-next" data-lb="1" aria-label="Next photo"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 5l7 7-7 7" fill="none" stroke="currentColor" stroke-width="1.8"/></svg></button>
        <button type="button" class="round-btn lb-close" data-lb-close aria-label="Close"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg></button>
      </div>
    </dialog>
  </section>`;
}

export function mountLookbook(root) {
  const section = $('[data-looks]', root);
  if (!section) return () => {};
  const edit = isPreviewMode();
  const strip = $('[data-strip]', section);
  const dialog = $('[data-lightbox]', section);
  const urls = new Set();
  hydrate(section);

  // ---------- slot helpers ----------
  const slotOf = (el) => el.closest('.look[data-look]');
  function showImage(slot, src) {
    const img = $('.look-img', slot);
    img.src = src;
    img.hidden = false;
    $('.look-placeholder', slot)?.setAttribute('hidden', '');
    $('[data-open]', slot).hidden = false;
    slot.setAttribute('data-has-image', '');
  }
  function clearImage(slot) {
    const look = allLooks(true).find((l) => l.id === slot.dataset.look);
    if (look?.image) {
      showImage(slot, look.image);
    } else {
      const img = $('.look-img', slot);
      img.removeAttribute('src');
      img.hidden = true;
      $('.look-placeholder', slot)?.removeAttribute('hidden');
      $('[data-open]', slot).hidden = true;
      slot.removeAttribute('data-has-image');
    }
    $('[data-remove]', slot).hidden = true;
    slot.classList.remove('is-trial');
  }

  // ---------- preview mode: load + accept trial photos ----------
  if (edit) {
    $$('.look[data-look]', section).forEach(async (slot) => {
      const blob = await idbGet(slot.dataset.look).catch(() => null);
      if (blob) {
        const u = URL.createObjectURL(blob);
        urls.add(u);
        showImage(slot, u);
        slot.classList.add('is-trial');
        $('[data-remove]', slot).hidden = false;
      }
    });

    async function accept(slot, file) {
      if (!file || !file.type.startsWith('image/')) return;
      await idbSet(slot.dataset.look, file);
      const u = URL.createObjectURL(file);
      urls.add(u);
      showImage(slot, u);
      slot.classList.add('is-trial');
      $('[data-remove]', slot).hidden = false;
    }

    section.addEventListener('change', (e) => {
      if (e.target.matches('[data-file]')) accept(slotOf(e.target), e.target.files[0]);
    });
    section.addEventListener('dragover', (e) => {
      const slot = slotOf(e.target);
      if (!slot) return;
      e.preventDefault();
      slot.classList.add('is-over');
    });
    section.addEventListener('dragleave', (e) => slotOf(e.target)?.classList.remove('is-over'));
    section.addEventListener('drop', (e) => {
      const slot = slotOf(e.target);
      if (!slot) return;
      e.preventDefault();
      slot.classList.remove('is-over');
      accept(slot, e.dataTransfer.files[0]);
    });
    section.addEventListener('click', async (e) => {
      const btn = e.target.closest('[data-remove]');
      if (!btn) return;
      const slot = slotOf(btn);
      await idbDel(slot.dataset.look);
      clearImage(slot);
    });

    $('[data-add]', section)?.addEventListener('submit', (e) => {
      e.preventDefault();
      const p = getProductById(e.target.product.value);
      const look = { id: uid('trial'), productId: p.id, color: p.colors[0].name, image: '', model: '', caption: '' };
      extras.write([...extras.read(), look]);
      const tmp = document.createElement('div');
      tmp.innerHTML = slotHTML(look, true);
      const slot = tmp.firstElementChild;
      e.target.closest('.look-add').before(slot);
      hydrate(slot);
      slot.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
    });
  }

  // ---------- strip scrolling ----------
  $$('[data-scroll]', section).forEach((b) =>
    b.addEventListener('click', () => strip.scrollBy({ left: Number(b.dataset.scroll) * strip.clientWidth * 0.8, behavior: 'smooth' }))
  );

  // ---------- lightbox ----------
  let index = 0;
  const withImages = () => $$('.look[data-has-image]', section);
  function show(i) {
    const list = withImages();
    if (!list.length) return;
    index = (i + list.length) % list.length;
    const slot = list[index];
    const img = $('.look-img', slot);
    const link = $('figcaption a', slot);
    $('[data-lb-img]', dialog).src = img.src;
    $('[data-lb-img]', dialog).alt = img.alt;
    const look = allLooks(edit).find((l) => l.id === slot.dataset.look);
    $('[data-lb-cap]', dialog).textContent = look?.caption || img.alt;
    $('[data-lb-shop]', dialog).href = link.getAttribute('href');
    const multi = list.length > 1;
    $$('[data-lb]', dialog).forEach((b) => (b.hidden = !multi));
  }
  section.addEventListener('click', (e) => {
    const open = e.target.closest('[data-open]');
    if (!open) return;
    show(withImages().indexOf(slotOf(open)));
    dialog.showModal();
  });
  $$('[data-lb]', dialog).forEach((b) => b.addEventListener('click', () => show(index + Number(b.dataset.lb))));
  $('[data-lb-close]', dialog).addEventListener('click', () => dialog.close());
  $('[data-lb-shop]', dialog).addEventListener('click', () => dialog.close());
  dialog.addEventListener('click', (e) => e.target === dialog && dialog.close());
  dialog.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowRight') show(index + 1);
    if (e.key === 'ArrowLeft') show(index - 1);
  });

  return () => {
    if (dialog.open) dialog.close();
    urls.forEach((u) => URL.revokeObjectURL(u));
  };
}
