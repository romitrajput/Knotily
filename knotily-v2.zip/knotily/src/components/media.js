// One place that decides how a garment image is shown:
// real photo (if provided) -> rendered 3D thumbnail -> flat silhouette (no WebGL).
import { hasWebGL, hydrateThumbs } from '../gl/garments.js';
import { silhouetteSVG } from '../gl/garmentTypes.js';
import { getProductById } from '../services/catalog.js';
import { esc } from '../lib/util.js';

const BLANK = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';

export function garmentImg(p, color, { side = 'front', eager = false } = {}) {
  const c = color || p.colors[0];
  const alt = `${p.name} in ${c.name}${side === 'back' ? ', back' : ''}`;
  const photo = p.images?.[c.name] || p.images?.default;
  if (photo) return `<img src="${esc(photo)}" alt="${esc(alt)}" loading="${eager ? 'eager' : 'lazy'}" decoding="async" />`;
  if (!hasWebGL()) return silhouetteSVG(p.art, c.hex, esc(alt));
  return `<img data-thumb="${p.id}|${esc(c.name)}|${side}" src="${BLANK}" alt="${esc(alt)}" decoding="async" />`;
}

export const hydrate = (root) => hydrateThumbs(root, getProductById);
