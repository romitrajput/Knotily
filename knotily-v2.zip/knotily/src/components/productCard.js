import { garmentImg } from './media.js';
import { formatPrice, esc } from '../lib/util.js';
import { moodFor } from '../lib/mood.js';

export function productCard(p) {
  const flag = p.stock === 'out' ? 'Sold out' : p.stock === 'low' ? 'Low stock' : p.discountPct ? `${p.discountPct}% off` : p.isNew ? 'New' : '';
  const hot = p.stock === 'low' || (p.discountPct && p.stock !== 'out');
  return `
    <article class="card">
      <a class="card-link" href="/product/${p.slug}">
        <div class="card-media" style="--spot:${moodFor(p.colors[0]).spot}">
          ${flag ? `<span class="flag ${hot ? 'flag-hot' : ''}">${flag}</span>` : ''}
          <div class="card-front">${garmentImg(p, p.colors[0])}</div>
          <div class="card-back" aria-hidden="true">${garmentImg(p, p.colors[0], { side: 'back' })}</div>
        </div>
        <div class="card-info">
          <h3 class="card-name">${esc(p.name)}</h3>
          <p class="card-price">${p.compareAt ? `<s>${formatPrice(p.compareAt)}</s> ` : ''}${formatPrice(p.price)}</p>
        </div>
      </a>
      <ul class="swatches" aria-label="Colours: ${p.colors.map((c) => esc(c.name)).join(', ')}">
        ${p.colors.map((c) => `<li style="--sw:${c.hex}"></li>`).join('')}
      </ul>
    </article>`;
}
