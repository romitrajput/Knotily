// "Try-on" stage: the live 3D garment, its tie-on colour tags and front/back control.
// Used by the rack's focus view and by the product page.
import { createViewer, hasWebGL } from '../gl/garments.js';
import { silhouetteSVG, inkFor } from '../gl/garmentTypes.js';
import { prefersReducedMotion, esc } from '../lib/util.js';

export function tagsHTML(product, current) {
  return product.colors
    .map(
      (c) => `<button type="button" class="tag" role="radio" aria-checked="${c.name === current.name}" data-color="${esc(c.name)}" style="--c:${c.hex};--t:${inkFor(c.hex)}">
        <span class="tag-string" aria-hidden="true"></span>
        <span class="tag-card"><span class="tag-swatch"></span><span class="tag-name">${esc(c.name)}</span></span>
      </button>`
    )
    .join('');
}

export function mountTryOn(host, product, color, { onColor = () => {}, onSide = () => {} } = {}) {
  let p = product;
  let c = color;
  let viewer = null;
  let lastSide = 'front';

  host.innerHTML = `
    <div class="tryon-canvas-wrap">
      ${hasWebGL() ? '<canvas class="tryon-canvas" aria-label="3D model. Drag sideways to turn it."></canvas>' : `<div class="tryon-flat">${silhouetteSVG(p.art, c.hex, esc(p.name))}</div>`}
      <div class="tags" role="radiogroup" aria-label="Colour" data-tags>${tagsHTML(p, c)}</div>
    </div>`;

  const canvas = host.querySelector('canvas');
  const tags = host.querySelector('[data-tags]');

  if (canvas) {
    viewer = createViewer(canvas, p, c, {
      reducedMotion: prefersReducedMotion(),
      onTurn: () => {
        const s = viewer?.side();
        if (s && s !== lastSide) {
          lastSide = s;
          onSide(s);
        }
      },
    });
  }

  function selectColor(name) {
    const next = p.colors.find((x) => x.name === name);
    if (!next) return;
    c = next;
    tags.querySelectorAll('.tag').forEach((t) => t.setAttribute('aria-checked', String(t.dataset.color === name)));
    if (viewer) viewer.setColor(c);
    else host.querySelector('.tryon-flat').innerHTML = silhouetteSVG(p.art, c.hex, esc(p.name));
    onColor(c);
  }

  tags.addEventListener('click', (e) => {
    if (viewer?.busy()) return;
    const t = e.target.closest('.tag');
    if (t) selectColor(t.dataset.color);
  });
  tags.addEventListener('keydown', (e) => {
    const dir = e.key === 'ArrowDown' || e.key === 'ArrowRight' ? 1 : e.key === 'ArrowUp' || e.key === 'ArrowLeft' ? -1 : 0;
    if (!dir) return;
    e.preventDefault();
    const i = p.colors.findIndex((x) => x.name === c.name);
    const n = p.colors[(i + dir + p.colors.length) % p.colors.length];
    selectColor(n.name);
    tags.querySelector(`[data-color="${CSS.escape(n.name)}"]`)?.focus();
  });

  return {
    ready: viewer ? viewer.ready : Promise.resolve(),
    color: () => c,
    // Unhook, fold, slide into the Knot'ily bag, carried off. Resolves when the bag has left.
    async purchase() {
      if (!viewer || prefersReducedMotion()) return;
      host.classList.add('is-buying');
      await viewer.purchase();
      if (canvas.isConnected) await flyToBag(canvas);
    },
    rehang() {
      host.classList.remove('is-buying');
      viewer?.rehang();
    },
    showSide(side) {
      if (viewer?.busy()) return;
      viewer?.showSide(side);
      lastSide = side;
      onSide(side);
    },
    async setProduct(prod, col) {
      p = prod;
      c = col || prod.colors[0];
      lastSide = 'front';
      tags.innerHTML = tagsHTML(p, c);
      if (viewer) {
        await viewer.setProduct(p, c);
        viewer.showSide('front');
      } else host.querySelector('.tryon-flat').innerHTML = silhouetteSVG(p.art, c.hex, esc(p.name));
    },
    destroy() {
      viewer?.destroy();
    },
  };
}

// The bag leaves the stage at the top; a small bag icon picks up from there
// and lands on the Bag button in the header.
function flyToBag(canvas) {
  const bag = document.querySelector('[data-open-cart]');
  if (!bag || !canvas) return Promise.resolve();
  const a = canvas.getBoundingClientRect();
  const b = bag.getBoundingClientRect();
  const el = document.createElement('div');
  el.className = 'fly-cart';
  el.innerHTML = '<svg viewBox="0 0 32 32" aria-hidden="true"><path d="M11 11V8.5a5 5 0 0 1 10 0V11" fill="none" stroke="#EE6522" stroke-width="2.2" stroke-linecap="round"/><path d="M6 10.5h20l-1.4 18H7.4z" fill="#14219E" stroke="#EE6522" stroke-width="1.6" stroke-linejoin="round"/><path d="M12 19.5h8" stroke="#EE6522" stroke-width="2" stroke-linecap="round"/></svg>';
  document.body.appendChild(el);
  const sx = a.left + a.width * 0.62 - 20, sy = Math.max(8, a.top + 6);
  const ex = b.left + b.width / 2 - 20, ey = b.top + b.height / 2 - 20;
  const anim = el.animate(
    [
      { transform: `translate(${sx}px, ${sy}px) scale(0.6)`, opacity: 0 },
      { transform: `translate(${sx + 10}px, ${sy - 30}px) scale(1.3)`, opacity: 1, offset: 0.2 },
      { transform: `translate(${(sx + ex) / 2}px, ${Math.max(8, Math.min(sy, ey) - 40)}px) scale(1.1)`, opacity: 1, offset: 0.6 },
      { transform: `translate(${ex}px, ${ey}px) scale(0.5)`, opacity: 0.2 },
    ],
    { duration: 750, easing: 'cubic-bezier(.5,0,.3,1)', fill: 'forwards' }
  );
  return new Promise((res) => {
    let done = false;
    const finish = () => { if (done) return; done = true; el.remove(); res(); };
    anim.onfinish = finish;
    setTimeout(finish, 800);
  });
}
