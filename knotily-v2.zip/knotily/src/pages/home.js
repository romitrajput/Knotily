import { listProducts } from '../services/catalog.js';
import { garmentImg, hydrate } from '../components/media.js';
import { productCard } from '../components/productCard.js';
import { mountTryOn } from '../components/tryOn.js';
import { lookbookHTML, mountLookbook } from '../components/lookbook.js';
import { thumbnail, hasWebGL } from '../gl/garments.js';
import { buyBoxHTML, mountBuyBox } from '../components/buyBox.js';
import { playProductAudio, stopProductAudio } from '../components/productAudio.js';
import { priceHTML } from './product.js';
import { track } from '../lib/analytics.js';
import { formatPrice, esc, prefersReducedMotion, $, $$ } from '../lib/util.js';
import { config } from '../config.js';
import { setMood } from '../lib/mood.js';

const marquee = () => ['Drop 04 is live', 'No strings attached', 'Pull the string', `Free shipping over ${formatPrice(config.freeShippingThreshold)}`, 'Handle with care', 'Ships across India'];

export default async function home({ query = {} } = {}) {
  const all = await listProducts();
  if (!all.length) {
    return {
      name: 'home', title: '',
      html: `<section class="page-narrow"><h1 class="page-title">The next drop is on its way</h1><p>Nothing is live right now. Create an account and check back soon.</p><a class="btn" href="/account">Create an account</a></section>`,
    };
  }
  const tees = all.filter((p) => p.category === 'tees');
  const rackSet = query.rack === 'all' || !tees.length ? 'all' : 'tees';
  const items = rackSet === 'all' ? all : tees;
  const teeCount = tees.length;
  const n = items.length;
  const marqueeRow = marquee().map((m) => `<span>${m}</span><i aria-hidden="true"></i>`).join('');

  return {
    name: 'home',
    title: '',
    description: "Knot’ily Drop 04: tees, tanks, hoodies, varsity jackets, cargos and minis that tie, lace or knot. Turn the rack and try each piece in 3D.",
    html: `
    <section class="rack" data-rack aria-roledescription="carousel" aria-label="${config.currentDrop} rack">
      <h1 class="sr-only">Knot’ily ${config.currentDrop}</h1>
      <nav class="rack-sets" aria-label="Rack">
        <a href="/" ${rackSet === 'tees' ? 'aria-current="page"' : ''}>Oversized tees <span>${teeCount}</span></a>
        <a href="/?rack=all" ${rackSet === 'all' ? 'aria-current="page"' : ''}>Full drop <span>${all.length}</span></a>
      </nav>
      <div class="rack-stage" data-stage>
        <svg class="rack-rail" data-rail aria-hidden="true"><path /></svg>
        <div class="rack-world" data-world>
          ${items
            .map(
              (p, i) => `<button type="button" class="rack-item" data-i="${i}" aria-label="${esc(p.name)}, ${formatPrice(p.price)}">
                  ${garmentImg(p, p.colors[0], { eager: true })}
                </button>`
            )
            .join('')}
        </div>
        <div class="focus" data-focus hidden>
          <div class="tryon" data-tryon></div>
          <button type="button" class="focus-close" data-close aria-label="Back to the rack">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
          </button>
        </div>
      </div>

      <div class="rack-ui">
        <div class="browse" data-browse>
          <p class="rack-count" aria-live="polite"><span data-idx>01</span> / ${String(n).padStart(2, '0')}</p>
          <h2 class="rack-name" data-name></h2>
          <p class="rack-price" data-price></p>
          <div class="rack-ctrls">
            <button type="button" class="round-btn" data-prev aria-label="Previous piece"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="1.8"/></svg></button>
            <button type="button" class="btn" data-open>Try it on</button>
            <button type="button" class="round-btn" data-next aria-label="Next piece"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 5l7 7-7 7" fill="none" stroke="currentColor" stroke-width="1.8"/></svg></button>
          </div>
          <p class="rack-hint">Drag the rack to turn it</p>
        </div>

        <form class="detail" data-detail hidden novalidate>
          <h2 class="detail-name" data-d-name></h2>
          <p class="detail-price" data-d-price></p>
          <div class="seg" role="group" aria-label="View">
            <button type="button" aria-pressed="true" data-side="front">Front</button>
            <button type="button" aria-pressed="false" data-side="back">Back</button>
          </div>
          ${buyBoxHTML()}
          <div class="detail-actions">
            <a class="text-link" data-d-link href="#">Full details</a>
          </div>
        </form>
      </div>
    </section>

    <div class="marquee" aria-hidden="true"><div class="marquee-track">${marqueeRow}${marqueeRow}</div></div>

    ${lookbookHTML({ title: 'On the body', intro: 'How each piece looks on a real person. Tap a photo to see it bigger and shop the look.' })}

    <section class="section index" aria-labelledby="index-title">
      <div class="section-head">
        <h2 id="index-title" class="display-sm">Oversized tees</h2>
        <p>Cut big, printed loud. Say it on the front, mean it on the back.</p>
      </div>
      <div class="grid grid-4">${all.filter((p) => p.category === 'tees').map((p) => productCard(p)).join('')}</div>
    </section>

    <section class="section index" aria-labelledby="rest-title">
      <div class="section-head">
        <h2 id="rest-title" class="display-sm">The rest of the drop</h2>
        <p>Tops, outerwear and bottoms with something to pull, lace or loosen.</p>
      </div>
      <div class="grid grid-4">${all.filter((p) => p.category !== 'tees').map((p) => productCard(p)).join('')}</div>
    </section>

    <section class="section manifesto" aria-labelledby="mf-title">
      <h2 id="mf-title" class="display">Made to be undone</h2>
      <div class="manifesto-cols">
        <p>Knot’ily makes clothes with a little trouble built in. Pull a drawcord, loosen a lace, drop a strap, and the same piece goes from daytime to after dark.</p>
        <p>We cut each style in short runs and never restock a colour once it's gone. <a class="text-link" href="/story">Read the story</a></p>
      </div>
    </section>`,

    mount(root) {
      const cleanups = [];
      const reduced = prefersReducedMotion();
      const rack = $('[data-rack]', root);
      const stage = $('[data-stage]', root);
      const world = $('[data-world]', root);
      const rail = $('[data-rail]', root);
      const els = $$('.rack-item', root);
      const focus = $('[data-focus]', root);
      const browse = $('[data-browse]', root);
      const detail = $('[data-detail]', root);
      const colorOf = new Map(items.map((p) => [p.id, p.colors[0]]));

      hydrate(root);

      // ---------- ring geometry ----------
      const step = (Math.PI * 2) / n;
      const st = { rot: 0, target: 0, vel: 0, R: 300, Rz: 220, w: 200, h: 240, dragging: false, moved: 0, lastX: 0, raf: 0, focused: false, shown: -1 };
      // Landing moment: the rack swings round into place once, on arrival.
      if (!reduced) {
        st.rot = -Math.PI * 1.35;
        rack.classList.add('is-arriving');
        setTimeout(() => rack.classList.remove('is-arriving'), 1600);
      }

      function layout() {
        const W = stage.clientWidth;
        const H = stage.clientHeight;
        const mobile = W < 700;
        st.h = Math.min(H * (mobile ? 0.74 : 0.78), mobile ? 420 : 620);
        st.w = st.h * (600 / 720);
        st.R = Math.min(W * (mobile ? 0.36 : 0.32), 560);
        st.Rz = st.R * 0.7;
        world.style.setProperty('--iw', `${st.w}px`);
        world.style.setProperty('--ih', `${st.h}px`);
        drawRail(W, H, mobile);
        place();
      }

      // The rail is drawn as the perspective projection of the ring the hooks hang on.
      function drawRail(W, H, mobile) {
        const persp = mobile ? 900 : 1500;
        const ox = W / 2, oy = -0.4 * H;
        const wx = W / 2, wy = world.offsetTop;
        const hookY = wy + st.h * 0.045;
        const pts = [];
        for (let k = 0; k <= 96; k++) {
          const a = (k / 96) * Math.PI * 2;
          const x = wx + Math.sin(a) * st.R;
          const z = (Math.cos(a) - 1) * st.Rz;
          const f = persp / (persp - z);
          pts.push(`${(ox + (x - ox) * f).toFixed(1)},${(oy + (hookY - oy) * f).toFixed(1)}`);
        }
        rail.setAttribute('viewBox', `0 0 ${W} ${H}`);
        rail.querySelector('path').setAttribute('d', `M${pts.join('L')}Z`);
      }

      const current = () => (((Math.round(-st.target / step) % n) + n) % n);

      function place() {
        els.forEach((el, i) => {
          const a = i * step + st.rot;
          const cos = Math.cos(a);
          const depth = (1 - cos) / 2;
          const x = Math.sin(a) * st.R;
          const z = (cos - 1) * st.Rz;
          el.style.transform = `translate3d(${x.toFixed(1)}px,0,${z.toFixed(1)}px)`;
          el.style.zIndex = String(Math.round((1 - depth) * 100));
          if (!st.focused) {
            el.style.filter = depth > 0.04 ? `blur(${(depth * 7).toFixed(2)}px)` : 'none';
            el.style.opacity = String(1 - depth * 0.5);
          }
        });
      }

      function tick() {
        st.raf = 0;
        if (!st.dragging) {
          const d = st.target - st.rot;
          st.rot += reduced ? d : d * (rack.classList.contains('is-arriving') ? 0.045 : 0.12);
        }
        place();
        const live = (((Math.round(-st.rot / step) % n) + n) % n);
        if (live !== st.shown) updateBrowse(live);
        if (st.dragging || Math.abs(st.target - st.rot) > 0.0005) st.raf = requestAnimationFrame(tick);
        else st.rot = st.target;
      }
      const kick = () => { if (!st.raf) st.raf = requestAnimationFrame(tick); };

      function goTo(i) {
        // shortest way round
        const cur = -st.target / step;
        let delta = ((i - cur) % n + n) % n;
        if (delta > n / 2) delta -= n;
        st.target = -(cur + delta) * step;
        kick();
        updateBrowse();
        track('rack_turn', { product_id: items[i]?.id });
      }

      function updateBrowse(at) {
        const i = at ?? current();
        st.shown = i;
        const p = items[i];
        if (!st.focused) setMood(colorOf.get(p.id));
        $('[data-idx]', root).textContent = String(i + 1).padStart(2, '0');
        $('[data-name]', root).textContent = p.name;
        $('[data-price]', root).innerHTML = priceHTML(p);
        els.forEach((el, k) => el.setAttribute('aria-current', String(k === i)));
      }

      // ---------- input ----------
      const onDown = (e) => {
        if (st.focused || e.button !== 0) return;
        st.dragging = true;
        st.moved = 0;
        st.lastX = e.clientX;
        st.vel = 0;
      };
      const onMove = (e) => {
        if (!st.dragging) return;
        const dx = e.clientX - st.lastX;
        st.lastX = e.clientX;
        st.moved += Math.abs(dx);
        const d = dx / (st.R * 1.1);
        st.rot += d;
        st.vel = d;
        st.target = st.rot;
        kick();
      };
      const onUp = () => {
        if (!st.dragging) return;
        st.dragging = false;
        const projected = st.rot + st.vel * 9;
        st.target = Math.round(projected / step) * step;
        kick();
        updateBrowse();
      };
      stage.addEventListener('pointerdown', onDown);
      window.addEventListener('pointermove', onMove, { passive: true });
      window.addEventListener('pointerup', onUp);
      window.addEventListener('pointercancel', onUp);
      cleanups.push(() => {
        window.removeEventListener('pointermove', onMove);
        window.removeEventListener('pointerup', onUp);
        window.removeEventListener('pointercancel', onUp);
      });

      stage.addEventListener(
        'wheel',
        (e) => {
          if (st.focused || Math.abs(e.deltaX) <= Math.abs(e.deltaY)) return;
          e.preventDefault();
          st.target -= e.deltaX / (st.R * 1.4);
          clearTimeout(st.wheelT);
          st.wheelT = setTimeout(() => {
            st.target = Math.round(st.target / step) * step;
            kick();
            updateBrowse();
          }, 140);
          kick();
        },
        { passive: false }
      );

      els.forEach((el, i) => {
        el.addEventListener('click', () => {
          if (st.moved > 6) return;
          if (i === current()) open();
          else goTo(i);
        });
        el.addEventListener('focus', () => i !== current() && goTo(i));
      });
      $('[data-prev]', root).addEventListener('click', () => goTo((current() - 1 + n) % n));
      $('[data-next]', root).addEventListener('click', () => goTo((current() + 1) % n));
      $('[data-open]', root).addEventListener('click', () => open());
      rack.addEventListener('keydown', (e) => {
        if (st.focused) {
          if (e.key === 'Escape') close();
          return;
        }
        if (e.target.closest('input, select, textarea')) return;
        if (e.key === 'ArrowRight') { e.preventDefault(); goTo((current() + 1) % n); }
        if (e.key === 'ArrowLeft') { e.preventDefault(); goTo((current() - 1 + n) % n); }
      });

      // ---------- focus (try-on) ----------
      let tryOn = null;
      let focusP = null;
      let box = null;

      function setSidePressed(side) {
        $$('[data-side]', detail).forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.side === side)));
      }

      async function open() {
        const i = current();
        const p = items[i];
        focusP = p;
        st.focused = true;
        st.openedAt = performance.now();
        rack.classList.add('is-focus');
        els.forEach((el) => {
          el.style.filter = '';
          el.style.opacity = '';
        });
        focus.hidden = false;
        browse.hidden = true;
        detail.hidden = false;
        $('[data-d-name]', detail).textContent = p.name;
        $('[data-d-price]', detail).innerHTML = priceHTML(p);
        $('[data-d-link]', detail).href = `/product/${p.slug}?color=${encodeURIComponent(colorOf.get(p.id).name)}`;
        detail.querySelectorAll('input[name="size"]').forEach((i) => (i.checked = false));
        if (!box) {
          box = mountBuyBox(detail, { product: p, color: colorOf.get(p.id), source: 'rack', beforeNavigate: () => tryOn?.purchase() });
        } else box.setProduct(p, colorOf.get(p.id));
        setSidePressed('front');
        track('try_on_open', { product_id: p.id });
        track('product_view', { product_id: p.id, color: colorOf.get(p.id).name, price: p.price, source: 'rack' });
        playProductAudio(p);

        const host = $('[data-tryon]', focus);
        if (!tryOn) {
          tryOn = mountTryOn(host, p, colorOf.get(p.id), {
            onSide: (side) => {
              setSidePressed(side);
              if (side === 'back') track('view_back', { product_id: focusP.id });
            },
            onColor: (c) => {
              colorOf.set(focusP.id, c);
              setMood(c);
              box?.setColor(c);
              track('color_change', { product_id: focusP.id, color: c.name, source: 'rack' });
              $('[data-d-link]', detail).href = `/product/${focusP.slug}?color=${encodeURIComponent(c.name)}`;
              const idx = items.indexOf(focusP);
              const img = els[idx].querySelector('img[data-thumb]');
              if (img && hasWebGL()) thumbnail(focusP, c).then((u) => (img.src = u));
            },
          });
        } else {
          await tryOn.setProduct(p, colorOf.get(p.id));
        }
        await tryOn.ready;
        requestAnimationFrame(() => focus.classList.add('in'));
        $('[data-close]', focus).focus({ preventScroll: true });
      }

      function close() {
        if (!st.focused || box?.busy()) return;
        st.focused = false;
        stopProductAudio();
        focus.classList.remove('in');
        rack.classList.remove('is-focus');
        detail.hidden = true;
        browse.hidden = false;
        setTimeout(() => {
          if (!st.focused) focus.hidden = true;
        }, 350);
        place();
        els[current()].focus({ preventScroll: true });
      }

      $('[data-close]', focus).addEventListener('click', () => !focus.querySelector('.is-buying') && close());
      stage.addEventListener('click', (e) => {
        if (!st.focused || performance.now() - st.openedAt < 400 || focus.querySelector('.is-buying')) return;
        if (!e.target.closest('.tryon, .focus-close')) close();
      });
      $$('[data-side]', detail).forEach((b) => b.addEventListener('click', () => tryOn?.showSide(b.dataset.side)));



      const ro = new ResizeObserver(layout);
      ro.observe(stage);
      cleanups.push(() => ro.disconnect());
      updateBrowse();
      layout();
      kick();

      cleanups.push(mountLookbook(root));

      return () => {
        cancelAnimationFrame(st.raf);
        stopProductAudio();
        tryOn?.destroy();
        cleanups.forEach((fn) => fn());
      };
    },
  };
}
