import { getProduct, getRelated, getCategory } from '../services/catalog.js';
import { productCard } from '../components/productCard.js';
import { hydrate } from '../components/media.js';
import { mountTryOn } from '../components/tryOn.js';
import { buyBoxHTML, mountBuyBox } from '../components/buyBox.js';
import { galleryHTML, mountGallery, reviewsHTML, starsHTML } from '../components/gallery.js';
import { playProductAudio, stopProductAudio } from '../components/productAudio.js';
import { track } from '../lib/analytics.js';
import { formatPrice, esc, $, $$ } from '../lib/util.js';
import { config } from '../config.js';
import { setMood } from '../lib/mood.js';

export function priceHTML(p) {
  return `${p.compareAt ? `<s>${formatPrice(p.compareAt)}</s> ` : ''}${formatPrice(p.price)}${p.discountPct ? ` <span class="off">${p.discountPct}% off</span>` : ''}`;
}

export default async function product({ params, query }) {
  const p = await getProduct(params.slug);
  if (!p) return (await import('./notFound.js')).default();
  const related = await getRelated(p, 4);
  const cat = getCategory(p.category);
  const color = p.colors.find((c) => c.name === query.color) || p.colors[0];
  const flag = p.stock === 'out' ? '<span class="flag">Sold out</span>' : p.stock === 'low' ? '<span class="flag flag-hot">Low stock</span>' : p.isNew ? '<span class="flag">New</span>' : '';

  return {
    name: 'product',
    title: p.name,
    description: p.description,
    html: `
    <section class="pdp">
      <div class="pdp-stage">
        ${flag}
        <div class="tryon tryon-pdp" data-tryon style="--tags:${p.colors.length}"></div>
        <p class="pdp-hint">Drag to turn. Tap a tag to change colour.</p>
      </div>

      <div class="pdp-info">
        <nav class="crumbs" aria-label="Breadcrumb">
          <ol><li><a href="/shop">Shop</a></li>${cat ? `<li><a href="/shop/${esc(cat.id)}">${esc(cat.label)}</a></li>` : ''}</ol>
        </nav>
        <h1 class="pdp-name">${esc(p.name)}</h1>
        ${p.rating ? `<a class="pdp-rating" href="#reviews">${starsHTML(Number(p.rating.avg))} <span>${esc(p.rating.avg)} (${p.rating.count})</span></a>` : ''}
        <p class="pdp-price">${priceHTML(p)}</p>
        <p class="pdp-color">Colour: <strong data-color-name>${esc(color.name)}</strong></p>

        <div class="seg" role="group" aria-label="View">
          <button type="button" aria-pressed="true" data-side="front">Front</button>
          <button type="button" aria-pressed="false" data-side="back">Back</button>
        </div>

        <form class="pdp-form" data-pdp-form novalidate>
          ${buyBoxHTML()}
          <p class="pdp-ship">${p.price >= config.freeShippingThreshold ? 'Ships free.' : `Free shipping over ${formatPrice(config.freeShippingThreshold)}.`} Dispatched in 2–3 working days. 7-day returns.</p>
        </form>

        ${p.description ? `<p class="pdp-desc">${esc(p.description)}</p>` : ''}

        <div class="accordion">
          ${p.details.length ? `<details open><summary>Details</summary><ul>${p.details.map((d) => `<li>${esc(d)}</li>`).join('')}</ul></details>` : ''}
          <details><summary>Size guide</summary>
            <table class="size-table"><caption class="sr-only">Body measurements in centimetres</caption>
              <thead><tr><th scope="col">Size</th><th scope="col">Chest</th><th scope="col">Length</th></tr></thead>
              <tbody>
                <tr><th scope="row">XS</th><td>104</td><td>68</td></tr>
                <tr><th scope="row">S</th><td>110</td><td>70</td></tr>
                <tr><th scope="row">M</th><td>116</td><td>72</td></tr>
                <tr><th scope="row">L</th><td>122</td><td>74</td></tr>
                <tr><th scope="row">XL</th><td>128</td><td>76</td></tr>
                <tr><th scope="row">XXL</th><td>134</td><td>78</td></tr>
              </tbody></table>
            <p>Garment measurements in centimetres. Oversized pieces are cut big on purpose: size down for a closer fit.</p></details>
          <details><summary>Shipping and returns</summary><p>Dispatched in 2–3 working days. Return unworn pieces with tags within 7 days of delivery.</p></details>
        </div>
      </div>
    </section>

    ${galleryHTML(p, color.name)}
    ${reviewsHTML(p)}

    ${related.length ? `<section class="section related" aria-labelledby="rel-title">
      <div class="section-head"><h2 id="rel-title" class="display-sm">Wear it with</h2></div>
      <div class="grid grid-4">${related.map((r) => productCard(r)).join('')}</div>
    </section>` : ''}`,

    mount(root) {
      const form = $('[data-pdp-form]', root);
      const colorName = $('[data-color-name]', root);
      const sideBtns = $$('[data-side]', root);
      const gallery = mountGallery(root, p);
      const pressed = (side) => sideBtns.forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.side === side)));
      let box;

      const tryOn = mountTryOn($('[data-tryon]', root), p, color, {
        onSide: (side) => {
          pressed(side);
          if (side === 'back') track('view_back', { product_id: p.id });
        },
        onColor: (c) => {
          setMood(c);
          colorName.textContent = c.name;
          box.setColor(c);
          gallery.setColor(c.name);
          track('color_change', { product_id: p.id, color: c.name });
          const url = new URL(location.href);
          url.searchParams.set('color', c.name);
          history.replaceState({}, '', url.pathname + url.search);
        },
      });
      box = mountBuyBox(form, {
        product: p,
        color,
        source: 'pdp',
        beforeNavigate: () => tryOn.purchase(),
      });
      sideBtns.forEach((b) => b.addEventListener('click', () => tryOn.showSide(b.dataset.side)));
      setMood(color);
      hydrate(root);
      track('product_view', { product_id: p.id, color: color.name, price: p.price });
      playProductAudio(p);

      return () => {
        stopProductAudio();
        tryOn.destroy();
      };
    },
  };
}
