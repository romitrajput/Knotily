import { listProducts, listCategories, getCategory, loadCatalog } from '../services/catalog.js';
import { track } from '../lib/analytics.js';
import { productCard } from '../components/productCard.js';
import { hydrate } from '../components/media.js';
import { navigate } from '../router.js';
import { $, esc } from '../lib/util.js';

const SORTS = [
  { id: 'featured', label: 'Featured' },
  { id: 'new', label: 'Newest drop first' },
  { id: 'price-asc', label: 'Price, low to high' },
  { id: 'price-desc', label: 'Price, high to low' },
];

export default async function shop({ params, query }) {
  await loadCatalog();
  const category = params.category || 'all';
  const cat = getCategory(category);
  if (params.category && !cat) {
    const nf = await import('./notFound.js');
    return nf.default();
  }
  const sort = SORTS.some((s) => s.id === query.sort) ? query.sort : 'featured';
  const items = await listProducts({ category, sort });
  const cats = listCategories();
  const qs = sort !== 'featured' ? `?sort=${sort}` : '';

  return {
    name: 'shop',
    title: cat ? cat.label : 'All pieces',
    description: cat ? cat.blurb : "Shop every Knot’ily piece: tops, outerwear and bottoms.",
    html: `
    <section class="shop">
      <header class="shop-head">
        <h1 class="display">${cat ? esc(cat.label) : 'All pieces'}</h1>
        <p>${cat ? esc(cat.blurb) : 'Everything we have right now.'}</p>
      </header>
      <div class="shop-bar">
        <nav class="chips" aria-label="Categories">
          <a class="chip" href="/shop${qs}" ${category === 'all' ? 'aria-current="page"' : ''}>All</a>
          ${cats.map((c) => `<a class="chip" href="/shop/${c.id}${qs}" ${category === c.id ? 'aria-current="page"' : ''}>${esc(c.label)}</a>`).join('')}
        </nav>
        <label class="sort">
          <span>Sort by</span>
          <select data-sort>${SORTS.map((s) => `<option value="${s.id}" ${s.id === sort ? 'selected' : ''}>${s.label}</option>`).join('')}</select>
        </label>
      </div>
      <p class="result-count" aria-live="polite">${items.length} ${items.length === 1 ? 'piece' : 'pieces'}</p>
      ${
        items.length
          ? `<div class="grid grid-4">${items.map((p) => productCard(p)).join('')}</div>`
          : `<div class="empty"><p>Nothing here right now. The next drop lands soon.</p><a class="btn" href="/shop">See everything</a></div>`
      }
    </section>`,
    mount(root) {
      $('[data-sort]', root).addEventListener('change', (e) => {
        const v = e.target.value;
        track('sort', { sort: v });
        const base = location.pathname;
        navigate(v === 'featured' ? base : `${base}?sort=${v}`, { replace: true, keepScroll: true });
      });
      hydrate(root);
    },
  };
}
